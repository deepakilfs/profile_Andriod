/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {

    //rest local storage data

    localStorage.SESSION_TOKEN = '';
    localStorage.PROFILE_NAME = '';
    localStorage.PROFILE_PIC = '';
	localStorage.PROFILE_ROLE_ID='';
	
	localStorage.PROFILE_CURRENTADDRESS='';


    var frm_id = 'frm_login';


    function validateForm() {
        var mpin = '';
        var mpinCount = 4;
        $("#" + frm_id + " input").each(function () {
            var tmp = this.value;
            if (tmp !== 'undefined' && tmp.length > 0) {
                mpin += tmp;
                $(this).removeClass('validation_error');
            } else {
                $(this).addClass('validation_error');
            }
        });


        if (mpin.length === mpinCount) {
            return mpin;
        } else {
            showMsgDialog(INVALID_INPUT_TITLE, "Please enter your mpin")
            return null;
        }

    }

    $("#but_forgot").bind("click", function () {
        var successCall = function () {
            window.location = "vertification.html";
        };
        
        if (confirm(MSG_CONFIRM_FORGOT_PASSWORD)) {
            requestForNewOTP(successCall, null);
        }

    });


    $("#but_login").bind("click", function () {
        //get form data
        var mpin = validateForm();

        if (mpin === null) {
            return;
        }
        var form_data = '';
        form_data = "Mpin=" + mpin + "&userDeviceRegId=" + getUserDeviceRegId();

        $.ajax({
            url: WEB_BASE_URL + WEB_METHOD_LOGIN,
            type: "POST",
            dataType: "json",
            data: form_data
        }).done(function (data, txtStatus, xhr) {
            // console.log('Response Header: ' + xhr.getResponseHeader('ResponseToken'));
            localStorage.SESSION_TOKEN = xhr.getResponseHeader('ResponseToken');

            //console.log(xhr.getAllResponseHeaders());
            processResponse(data);
        }).error(function (err) {
            // showMsgDialog(SERVER_ERROR_TILTLE, SERVER_ERROR_MSG);
        });

    });

    function processResponse(data) {
        var jsonObj = $.parseJSON(data);
        if (jsonObj[0].message === 'Invalid')
        {
            showMsgDialog(INVALID_INPUT_TITLE, "please enter correct MPIN");
        } else if (jsonObj[0].message === 'Success') {
            localStorage.PROFILE_PIC = jsonObj[0].Profile_pic_url;
            localStorage.PROFILE_EMAIL = jsonObj[0].EmailId;
            localStorage.PROFILE_NAME = jsonObj[0].Firstname + " " + jsonObj[0].LastName;	
			localStorage.PROFILE_ROLE_ID=jsonObj[0].RoleId;
			
			var Currentaddress=jsonObj[0].CurrentAddress;
			if (Currentaddress=='' || Currentaddress=='null')
			{
				window.location = "additionemployeeinfo.html";
			}
			else
			{
			    window.location = "dashboard.html";
			}
        } else {
            showMsgDialog(SERVER_ERROR_TILTLE, SERVER_ERROR_MSG);
        }
    }


});
